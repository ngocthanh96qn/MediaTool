
<?php $__env->startSection('content'); ?>
<div class="container text-center mt-5">
  <div class="row">
    <div class="col-xl-4">
      <div class="row">
        <div class="col-xl-12">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Token</th>
                <th scope="col">Ngày tạo</th>
              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $list_token; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td >
                  <p class="d-inline-block text-truncate" style="max-width: 150px;">
                    <?php echo e($element->access_token); ?>

                  </p>
                </td>
                <td><?php echo e($element->created_at); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-xl-12">
          <form action="<?php echo e(route('adminToken')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label> access_token </label>
              <input type="text" class="form-control" name="access_token" >
            </div>
            <button type="submit" class="btn btn-warning">Thiết lập Token</button>
          </form>
        </div>
      </div>
    </div>
    <div class="col-xl-6 offset-xl-2">
     <form action="<?php echo e(route('adminWeb')); ?>" method="POST" >
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-xl-6">

         <div class="form-group">
          <label> Id page  </label>
          <input type="text" class="form-control" name="id_page" placeholder="ex: 104651187547290" >
        </div>
        <div class="form-group">
          <label> Domain web liên kết  </label>
          <input type="text" class="form-control" name="domain" placeholder="ex: 24h.xaluanvn.net" >
        </div>
        <div class="form-group">
          <label> Id Ads  </label>
          <input type="text" class="form-control" name="id_ads" placeholder="ex: 0000_111" >
        </div>

      </div>
      <div class="col-xl-6">

       <div class="form-group">
        <label> Tên Page  </label>
        <input type="text" class="form-control" name="page_name" placeholder="ex: Đọc Tin Hay">
      </div>
      <div class="form-group">
        <label> Tên web  </label>
        <input type="text" class="form-control" name="web_name" placeholder="ex: 24h Xã Luận" >
      </div>
      <div class="form-group">
          <label> Id Analytics  </label>
          <input type="text" class="form-control" name="id_analytics" placeholder="UA-178506002-1" >
        </div>

    </div>
  </div>
  <button type="submit" class="btn btn-success">Cài Đặt Trang</button>
</form>
</div>


</div>
<div class="row mt-5 ">
  <div class="col-xl-12">

    <table class="table">
      <thead>
        <tr>
          <th scope="col">ID Trang</th>
          <th scope="col">tên Trang</th>
          <th scope="col">Domain web</th>
          <th scope="col">Tên Web</th>
          <th scope="col">Id Ads</th>
          <th scope="col">Id Analytics</th>
          <th scope="col">Xóa</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $list_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($element->id_page); ?></td>
          <td><?php echo e($element->page_name); ?></td>
          <td><?php echo e($element->domain); ?></td>
          <td><?php echo e($element->web_name); ?></td>
          <td><?php echo e($element->id_ads); ?></td>
          <td><?php echo e($element->id_analytics); ?></td>
          <td><a href="<?php echo e(route('deleteConfigWeb',$element->id)); ?>">Delete</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

  </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mediatool\resources\views/pages/config_admin.blade.php ENDPATH**/ ?>