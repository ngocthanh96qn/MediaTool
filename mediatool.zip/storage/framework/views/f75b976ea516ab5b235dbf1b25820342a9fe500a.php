<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MediaTool</title>
     <!-- Scripts -->
     <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
 
     <!-- Styles -->
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <?php $__env->startSection('content'); ?>
        
    <?php echo $__env->yieldSection(); ?>
</body>
</html><?php /**PATH C:\laragon\www\mediatool\resources\views/pages/layouts.blade.php ENDPATH**/ ?>